# Docs Pipeline — Sholanke Abdulhakeem

[![Docs CI](https://github.com/hakeemwza/docs-pipeline/actions/workflows/docs-ci.yml/badge.svg)](https://github.com/hakeemwza/docs-pipeline/actions/workflows/docs-ci.yml)

This repo takes the three portfolio samples from my [technical writing portfolio](https://github.com/hakeemwza) and puts them behind a CI pipeline that treats documentation like production code: linted, link-checked, and validated on every push.

## Why this exists

Most technical writing portfolios are static PDFs or Notion pages — readable, but unverifiable. This repo is the difference: every claim the docs make about an API is checked automatically, every time the content changes.

## What the pipeline checks

| Check | Tool | What it catches |
|---|---|---|
| Markdown style | `markdownlint-cli2` | Inconsistent formatting, broken heading structure |
| Broken links | `lychee` | Dead links to APIs, repos, or external references |
| Python samples compile | Standard library `py_compile`, via custom extraction script | Code samples that no longer parse — the #1 way doc examples silently rot |
| cURL requests match live spec | [Prism](https://github.com/stoplight/prism) mock server built from Stripe's public OpenAPI spec, via custom validation script | Request shapes (method, path, required params) that have drifted from the real API — no API keys required, nothing hits production |

## Repo structure

```
docs-pipeline/
├── .github/workflows/docs-ci.yml   # CI entrypoint — runs on every push to docs/ or scripts/
├── docs/
│   ├── 01-docs-audit-benjamn-install.md
│   ├── 02-api-reference-stripe-paymentintents.md
│   └── 03-onboarding-guide-tango-api.md
├── scripts/
│   ├── extract_code_blocks.py       # pulls fenced code blocks by language out of markdown
│   ├── validate_python_syntax.py    # compiles every extracted Python sample
│   └── validate_curl_against_mock.sh # runs cURL samples against a spec-generated mock
├── .markdownlint.yaml
├── .lycheeignore
└── requirements.txt
```

## Running checks locally

```bash
# Markdown lint (requires Node.js)
npx markdownlint-cli2 "docs/**/*.md" --config .markdownlint.yaml

# Link check (requires lychee: brew install lychee / cargo install lychee)
lychee docs/**/*.md

# Python sample validation
python3 scripts/extract_code_blocks.py --lang python --out /tmp/py_blocks docs/*.md
python3 scripts/validate_python_syntax.py /tmp/py_blocks

# cURL-against-spec validation (requires Node.js for Prism)
./scripts/validate_curl_against_mock.sh
```

## Scope and honesty notes

- The Stripe and Tango Card samples are written against those companies' **public** API documentation as portfolio demonstrations. They are not commissioned work and are labeled as such at the bottom of each doc.
- The cURL validation job checks *request shape* against Stripe's current published OpenAPI spec via a local mock — it proves the example hasn't drifted from the real API surface. It does not execute against Stripe's live API and requires no credentials.
- The Tango Card sample is validated for Python syntax and Markdown/link correctness only; Tango does not publish a machine-readable OpenAPI spec, so there's no mock-server check for it yet — noted here rather than silently skipped.
